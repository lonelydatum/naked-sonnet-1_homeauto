import start from '../../_common/js/tween.js'
start("hero_mask")