import start from '../../_common/js/tween_lb.js'

start('hero_mask')