import start from '../../_common/js/tween_online.js'
start('hero_mask')
