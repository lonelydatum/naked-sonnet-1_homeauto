import start from '../../_common/js/tween_mobile.js'
start()

